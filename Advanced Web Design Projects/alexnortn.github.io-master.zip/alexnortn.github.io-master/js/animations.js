$(document).ready(function() {
	$('#main article').each(function (index, element) {
		$(element).find('.contents').first().alwaysCenterIn(element, { top: -25 });
	});
});